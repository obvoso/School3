package Test;

class Circle2 {
	
	int radius;
	
	Circle2(){
		radius = (int)(Math.random() * 101);
	}

	@Override
	public String toString() {
		return "Circle2 [radius=" + radius + "]";
	}
	
}

public class Ex05 {
	
	public static void main(String[] args) {
		
		Circle2[] cArr = new Circle2[3];
		
		for (int i = 0; i < cArr.length; i++) {
			cArr[i] = new Circle2();
			System.out.println(cArr[i]);
		}
	}
}
