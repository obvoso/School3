package Ex;

public interface Animal {

	void walk();
	void fly();
	void sing();
}
