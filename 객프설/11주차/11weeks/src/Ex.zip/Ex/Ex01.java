package Ex;

class Bird implements Animal {

	@Override
	public void walk() {
		System.out.println("걷을 수 있음");
		
	}

	@Override
	public void fly() {
		System.out.println("날을 수 있음");
		
	}

	@Override
	public void sing() {
		System.out.println("노래 부를 수 있음");
	}
}

public class Ex01 {
	public static void main(String[] args) {
		
		Bird obj = new Bird();
		
		obj.walk();
		obj.fly();
		obj.sing();
	}
}
