package Ex;

public interface Queue {
	int dequeue();
	void enqueue(int value);
	boolean isEmpty();
}
