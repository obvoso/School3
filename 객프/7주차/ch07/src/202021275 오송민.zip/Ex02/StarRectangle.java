package Ex02;

public class StarRectangle {
	public static void main(String[] args) {
		for(int i = 0; i < 3; i++) {
			for(int j = 0; j < 7; j++) {
				System.out.printf("* ");
			}
			System.out.println();
		}
	}

}
